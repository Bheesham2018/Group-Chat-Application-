/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - group_chat_application
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`group_chat_application` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `group_chat_application`;

/*Table structure for table `messages` */

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  `message_time` datetime NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `messages` */

insert  into `messages`(`message_id`,`user_id`,`message`,`message_time`) values 
(2,1,'cskcls','2024-08-15 12:13:39'),
(3,1,'csmcs','2024-08-15 12:16:22'),
(4,1,'csmcs','2024-08-15 12:17:32'),
(5,1,'sdcvmsd,','2024-08-15 12:18:16'),
(6,1,'cscsl','2024-08-15 12:19:37'),
(7,1,'csmlcs','2024-08-15 12:20:23'),
(8,1,'jfweijfklwefklw','2024-08-15 13:09:26'),
(9,1,'hello','2024-08-15 13:09:36'),
(10,1,'hello','2024-08-15 13:09:38'),
(11,1,'cklsmcks','2024-08-15 13:17:30'),
(12,1,'i am here','2024-08-15 13:17:41'),
(13,1,'hello','2024-08-15 13:35:05'),
(14,1,'hello','2024-08-15 13:35:09'),
(15,1,'djasknd','2024-08-15 13:35:17'),
(16,1,'cmkslc','2024-08-15 13:35:51'),
(17,1,'hello john','2024-08-15 13:55:52'),
(18,2,'yes sir','2024-08-15 13:56:05'),
(19,2,'hello bro','2024-08-15 14:07:15'),
(20,1,'yes bro','2024-08-15 14:07:28'),
(21,3,'njnasjkncjnsjcnasjcnasjibcasjbvjmas jvbsam jasnjcasnmc jasbc masncmascnmasjcascj asjcnascjmasjcaskcjasmkcjasm cjaskc ascjn ascjas cn askcasjcjascnaskcnkasc','2024-08-15 14:34:26'),
(22,3,'casjnjasknfjisdnvknajilvbsdknnsdjkfnjsdjdsjjjjjjjjjjjjjjjjjjjjjjjjc sjkcnascknasbjhbna jhbvda hbvadfblsdnbfulisjdnbfsjnFHDBFNSBfns fsjhfsjdhBFLHJBFJHLabdjhibfadjkfbdiasjkf','2024-08-15 14:39:47'),
(23,1,'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','2024-08-15 15:13:00'),
(24,2,'hello','2024-08-15 15:18:48'),
(25,1,'hello','2024-08-15 15:33:37'),
(26,3,'yes','2024-08-15 15:33:57');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `gender` enum('Male') NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` varchar(30) NOT NULL,
  `profile_pic_path` blob NOT NULL,
  `user_password` varchar(30) NOT NULL,
  `online_offline` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `users` */

insert  into `users`(`user_id`,`first_name`,`last_name`,`gender`,`email`,`phone_number`,`profile_pic_path`,`user_password`,`online_offline`) values 
(1,'Roman','Reign','Male','roman@gmail.com','0302-1234567','uploads/1723746692_Roman_Reign.jpg','12345',0),
(2,'John','Cena','Male','cena@gmail.com','0302-1254567','uploads/1723746744_john_cena.jpg','12345',0),
(3,'Raja','Naveed','Male','raju@gmail.com','0302-1234567','uploads/1723746886_000000.jpg','12345',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
