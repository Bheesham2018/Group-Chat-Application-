<?php
session_start();
require_once("require/form_database.php");
$user = new Form_Database(HOSTNAME, USERNAME,PASSWORD,DATABASE_NAME);
extract($_REQUEST);
// print_r($_REQUEST);
if(isset($action) && $action == 'send_message'){
    $user_id = $_SESSION['user']['user_id'];
    // echo $user_id;
    // die;
    $message_is = htmlspecialchars($message_is);
$query = "INSERT INTO messages VALUES (NULL,'".$user_id."','".$message_is."',NOW())";
// echo $query;
// die;
 $flag=$user->execute_query($query);
 if($flag){
    echo "<p style='color:green' align='center'>Message send</p>";
 }
 else{
    echo "<p style='color:red' align='center'>Message did not Send</p>"; 
 }
}
elseif(isset($action)&& $action =='recieve'){
    $query = "SELECT * FROM messages JOIN users ON users.user_id = messages.user_id ORDER BY message_id DESC";
    $result = $user->execute_query($query);
    // print_r($result);
    // die;
        while($row = mysqli_fetch_assoc($result)){
            extract($row);
            $user = ($user_id==$_SESSION['user']['user_id'])?'lightblue':'lightgrey';
            $flt = ($user_id==$_SESSION['user']['user_id'])?'right':'left';
            ?>
            <div id="show">

           </div>
                    <div class="col-12">
                    <div class="col-6" style="float: <?=$flt?>; height:fit-content">
  <div class="border" style="background-color: <?=$user?>; ">
    <table>
      <tr>
        <td>
          <img src="<?=$profile_pic_path?>" alt="" height="50" width="50" style="position: relative; border-radius:50%">
        </td>
        <td>
          <span style="margin-left: 5px;margin-top: -15px;" ><?=$first_name." ".$last_name?></span>
        </td>
        <td></td>
      </tr>
      <tr>
        <td colspan="3">
          <div style="overflow-y: auto; max-height: 50px; padding: 10px;"> <!-- adjust max-height to your needs -->
            <p style="word-break: break-word;"><?=$message?></p>
          </div>
        </td>
      </tr>
    </table>
                    <p style="margin-top: 4px; float:right;"><?=date("j F Y h:i A" ,strtotime($message_time))?></p>
                    </div>    
                </div>                     
            
                    </div>

            <?php
        }
    
}
elseif(isset($action)&&$action =="users"){
    $id = $_SESSION['user']['user_id'];
    $query = "SELECT * FROM users WHERE user_id!='".$id."'  ORDER BY online_offline DESC ";
    $result = $user->execute_query($query);
    if($result->num_rows>0){
        while($row = mysqli_fetch_assoc($result)){
            extract($row);
            
            $color = ($online_offline==1)?'#228B22':'gray';
?>
                     <!-- users -->
                    <div class="col-12">
                    
                     <table>
                        <tr>
                            <td><img src="<?=$profile_pic_path?>" alt="" height="40" width="40" style="border-radius:50%" ></td>
                            <td style="width: 80%;"><span style="margin-top: 15px; margin-left: 5px; "><?=$first_name." ".$last_name?></span></td>
                            <td><span style="float:right; border-radius:50%; height:10px;width:10px; background-color:<?=$color?>" ></span></td>
                        </tr>
                     </table>                    
                </div>
<?php
    }
}
}
?>