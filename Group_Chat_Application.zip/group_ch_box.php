<?php

session_start();
if(!(isset($_SESSION['user']))){
    header("location:index.php?msg=Please Login First...!&color=red");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>group chat box</title>
    <link rel="stylesheet" href="require/grid_view.css">
    <style>
        h1{
            background-color: navy;
            color: yellow;
            border-radius: 5px;
        }
        .float{
            float: right;
        }
        a{
            text-decoration: none;
            background-color: lightgoldenrodyellow;
            margin-right: 5px;
            padding: 5px;
            color: green;
            border-radius: 5px;
        }
        h1{
            display: block;
        }
        .left_bar{
            border: 2px solid green;
            height: 500px;
        }
        .border{
            border: 1px solid green;
            height: 150px;
            clear: both;
            border-radius: 10px;
            padding: 10px;
            margin: 5px;
        }
        .inter_border{
            border: 1px solid green;
            height: 350px;
            clear: both;
            border-radius: 10px;
            padding: 10px;
            margin: 5px; 
            overflow: auto;
        }
        fieldset{
            width:10%;
            border-radius: 6px;
        }
        input{
            width: 800px;
            height: 40px;
            font-size: large;
        }
        button{
            height: 40px;
            width: 90px;
            background-color: navy;
            color: yellow;
            font-size: large;
        }
        /* .box{ */
            /* height: 20%; */
            /* width: 50%; */
            /* border: 1px solid gray; */
            /* overflow: auto; */
        /* } */
    </style>
    <script>
        function send(){
           var message_is = document.querySelector("#message_is").value;
           var mess = new XMLHttpRequest();
           mess.onreadystatechange= function(){
            if(mess.readyState==4 && mess.status ==200){
                // console.log(mess.responseText);
                document.querySelector("#show").innerHTML = mess.responseText
                document.querySelector("#message_is").value = "";
            }
           }
           mess.open("GET","ajax_process.php?action=send_message&message_is="+message_is);
           mess.send();
        }
        function load_this(){
            var mess = new XMLHttpRequest();
           mess.onreadystatechange= function(){
            if(mess.readyState==4 && mess.status ==200){
                // console.log(mess.responseText);
                document.querySelector("#messages_show").innerHTML = mess.responseText;
                users();
            }
           }
           mess.open("GET","ajax_process.php?action=recieve");
           mess.send();
        }
        function users(){
           var mess = new XMLHttpRequest();
           mess.onreadystatechange= function(){
            if(mess.readyState==4 && mess.status ==200){
                // console.log(mess.responseText);
                document.querySelector("#onlineUsers").innerHTML = mess.responseText;
            }
           }
           mess.open("GET","ajax_process.php?action=users");
           mess.send();
        }
        setInterval("load_this()",2000);
    </script>
</head>
<body onload="load_this()">
    <div class="row" style="background-color: navy; border-radius:10px">
        <div class="col-6">
            <h1>Group Chat</h1>
        </div>
        <div class="col-6" >
            <div class="float">
        <h1><?=$_SESSION['user']['first_name']." ".$_SESSION['user']['last_name']?><a href="logout.php">Logout</a></h1>
            </div>
    </div>
    </div>
    <div class="row">
        <div class="col-10">
            <div class="left_bar">
                <div class="row">
                    <div class="col-12">
                        <h1>Messages</h1>
                    </div>
                </div>
                <div class="row" >
                <div class="col-12 inter_border" id="messages_show">
                   
               </div>
                </div>
                <div class="message-box" style="margin-left: 10%;">
                    <table>
                        <tr>
                            <td style="position:relative" ><input type="text" name="" id="message_is"  ></td>
                            <td style="position: absolute;" onclick="send()"><button>SEND</button></td>
                        </tr>
                    </table>
                </div>
        </div>
        </div>
        <div class="col-2">
            <div class="left_bar" style="margin-left: 4px;">
                <div class="col-12">
                    <h1>Chat</h1>
                <div class="row">
                <div class="col-12 inter_border"id="onlineUsers" >
                
                </div>
            </div>
        </div>
    </div>
</body>
</html>