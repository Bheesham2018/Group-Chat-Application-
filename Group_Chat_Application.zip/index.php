<?php
session_start();
require_once("require/class_and_objects.php");
$user = new login_signup_form;
if(isset($_SESSION['user']['user_id'])){
    header("location:group_ch_box.php");
}
$user->set_action("process.php");
$user->set_method("POST");
echo $user->login();
?>