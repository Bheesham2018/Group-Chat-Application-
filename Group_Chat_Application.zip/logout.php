<?php
session_start();
require_once("require/form_database.php");
$user = new Form_Database(HOSTNAME, USERNAME,PASSWORD,DATABASE_NAME);
$query = "UPDATE users SET online_offline = '0' WHERE user_id = '".$_SESSION['user']['user_id']."';";
$user->execute_query($query);
session_destroy();
header("location:index.php?msg=Logout Successfully...!&color=red");
?>