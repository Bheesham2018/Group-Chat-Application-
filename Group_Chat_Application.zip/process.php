<?php
session_start();
require_once("require/form_database.php");
$user = new Form_Database(HOSTNAME, USERNAME,PASSWORD,DATABASE_NAME);
// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
extract($_POST);
if(isset($register) && isset($_FILES['profile_pic'])){
    extract($_FILES);
    $dir = "uploads";
    if(!is_dir($dir)){
       if(!mkdir($dir)){
          echo "Directory could not be created....!";
       }
    }
      $profile_picture = $_FILES['profile_pic']['name'];
      $profile_picture_path_name = $_FILES['profile_pic']['tmp_name']; 
  
      $profile_path = $dir."/".time()."_".$profile_picture;
      if(move_uploaded_file($profile_picture_path_name, $profile_path)){
        $query ="INSERT INTO users ";
        $query.="VALUES (null,'".$first_name."','".$last_name."','".$gender."','".$email."','".$phone_number."','".$profile_path."','".$user_password."',0)";
        // echo $query;
        // die;
       $flag = $user->execute_query($query);
        if($flag){
            header("location:register.php?msg=Registraction Successfull&color=green");
        }
        else{
            header("location:register.php?msg=Registraction Failed&color=red");
        }
}
    else{
        header("location:register.php?msg=All fields are Required&color=red");
    }

}
elseif(isset($login)){
    $query = "SELECT * FROM users WHERE email = '".$email."' AND user_password = '".$user_password."'";
    $result = $user->execute_query($query);
    if($result->num_rows>0){
        $row = mysqli_fetch_assoc($result);
        $_SESSION['user']=$row;
        $query = "UPDATE users SET online_offline = '1' ";
		$query .= "WHERE user_id='".$row['user_id']."'";
        $user->execute_query($query);
        header("location:group_ch_box.php");
    }
    else{
        header("location:index.php?msg=Invalid Email and Password&color=red");
    }

}
?>