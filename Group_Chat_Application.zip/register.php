<?php
require_once("require/class_and_objects.php");
$user = new login_signup_form;
$user->set_action("process.php");
$user->set_method("POST");
echo $user->signup();
?>