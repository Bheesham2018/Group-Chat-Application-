<?php
class login_signup_form{

        public $action ="";
        public $method = "";
        public function set_action($_action){
			$this->action = $_action; 
		}

		public function get_action(){
			return $this->action; 
		}

		public function set_method($_method){
			$this->method = $_method; 
		}

		public function get_method(){
			return $this->method; 
		}

    public function login(){
        ?>
        <head>
            <style>
                h1{
                    background-color: navy;
                    color: yellow;
                    margin: 10px;
                    border-radius: 5px;
                }
                fieldset{
                    width: max-content;
                    background-color: lightgray;
                }
                legend{
                    background-color: navy;
                    color: yellow;
                    font-size: x-large;
                    border-radius: 5px;
                }
                table{
                    font-size: x-large;
                }
                input{
                    font-size: x-large;
                }

            </style>
        </head>
        <center>
            <h1>Login Form</h1>
        <fieldset>
        <p style="color:<?=$_GET['color']??''?>;"><?=$_GET['msg']??'';?></p>
            <legend>Login Form...</legend>
            <form action="<?=$this->get_action();?>" method="<?=$this->get_method();?>">
                <table border="1">
                    <tr>
                        <th>Email:</th>
                        <td><input type="email" name="email" id="" placeholder="Enter Email"></td>
                    </tr>
                    <tr>
                        <th>Password:</th>
                        <td><input type="password" name="user_password" id="" placeholder="Enter Password"></td>
                    </tr>
                    <tr align="center">
                        <td colspan="2"><input type="submit" name="login" id="" value="Login">
                    <input type="reset" name="cancel" id="" value="Clear Form">
                    </td>
                    </tr>
                </table>
            </form>
            <span>If you have not already an account <a href="register.php"> Register Here</a></span>
        </fieldset>
        </center>
        <?php
    }
    public function signup(){
        ?>
         <head>
            <style>
                h1{
                    background-color: navy;
                    color: yellow;
                    margin: 10px;
                    border-radius: 5px;
                }
                fieldset{
                    width: max-content;
                    background-color: lightgray;
                }
                legend{
                    background-color: navy;
                    color: yellow;
                    font-size: x-large;
                    border-radius: 5px;
                }
                table{
                    font-size: x-large;
                }
                input{
                    font-size: x-large;
                }

            </style>
        </head>
        <center>
            <h1>Registraction Form</h1>
        <fieldset>
            <p style="color:<?=$_GET['color']??''?>;"><?=$_GET['msg']??'';?></p>
            <legend>Register Form...</legend>
            <form action="<?=$this->get_action();?>" method="<?=$this->get_method();?>" enctype="multipart/form-data">
                <table border="1">
    
                  <tr>
                        <th>First Name</th>
                        <td><input type="text" name="first_name" id="" placeholder="Enter First Name"></td>
                    </tr>
                    <tr>
                        <th>Last Name</th>
                        <td><input type="text" name="last_name" id="" placeholder="Enter Last Name"></td>
                    </tr>
                    <tr> <th>Gender</th>
                        <td>
                            <input type="radio" name="gender" id="" value="Male">Male
                            <input type="radio" name="gender" id="" value="Female">Female
                        </td>
                    </tr>
                    <tr>
                        <th>Email:</th>
                        <td><input type="email" name="email" id="" placeholder="Enter Email"></td>
                    </tr>
                    <tr>
                        <th>Phone Numeber:</th>
                        <td><input type="text" name="phone_number" id="" placeholder="Enter Phone Number"></td>
                    </tr>
                    <tr>
                        <th>Profile picture:</th>
                        <td><input type="file" name="profile_pic" id=""></td>
                    </tr>
                    <tr>
                        <th>Password:</th>
                        <td><input type="password" name="user_password" id="" placeholder="Enter Password"></td>
                    </tr>
                    <tr align="center">
                        <td colspan="2"><input type="submit" name="register" id="" value="Register">
                    <input type="reset" name="cancel" id="" value="Clear Form">
                    </td>
                    </tr>
                </table>
            </form>
            <span>If you have already an account <a href="index.php"> Login Here</a></span>
        </fieldset>
        </center>


        <?php

    }
    
}
?>